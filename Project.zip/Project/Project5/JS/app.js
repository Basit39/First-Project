function imageChange(element){
    var c=document.getElementById("img1");
    c.src=element.src
}

// function imageChange(){
//     var c=document.getElementById("img1");
//     var v=document.getElementById("img2");
//     c.src=v.src
//     document.getElementById("type1").innerText="hello"
    
// }



for(var i = 0; i <=bulb.length ; i++){
    document.getElementById('select1').innerHTML += `<option value=${i}>${bulb[i].title}</option>`
}

function item1(a){
    if(a!=0){
        document.getElementById("img1").src= bulb[a].image1;
        document.getElementById("img2").src=bulb[a].image2;
        document.getElementById("img3").src=bulb[a].image3;
        document.getElementById("img4").src=bulb[a].image4;
        document.getElementById("img5").src=bulb[a].image5;
        document.getElementById("type1").innerHTML=bulb[a].type;
        document.getElementById("price1").innerHTML=bulb[a].Price1;
        
    }
    else{
        document.getElementById("img1").src= bulb[0].image1;
        document.getElementById("img2").src=bulb[0].image2;
        document.getElementById("img3").src=bulb[0].image3;
        document.getElementById("img4").src=bulb[0].image4;
        document.getElementById("img5").src=bulb[0].image5;
        document.getElementById("type1").innerHTML="NULL";
        document.getElementById("condition").innerHTML="NULL";
        document.getElementById("price1").innerHTML="NULL";
    }
}