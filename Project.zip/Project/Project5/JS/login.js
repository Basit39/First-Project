function login(){
    var email=fm.email.value;
    var pass=fm.password.value;
    if(email==localStorage.getItem(`E-mail`)&& pass==localStorage.getItem(`Password`)){
        location.href="./index2.html"
        alert("loggedIn")
    }else{
        alert("incorrect")
    }
    

}