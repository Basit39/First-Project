function validation(){
    var usname=fm.name.value;
    var email=fm.email.value;
    var pass=fm.password.value;
    if(usname!=0 && email !=0 && pass!= 0){
        localStorage.setItem("Username", usname);
        localStorage.setItem("E-mail",email);
        localStorage.setItem("Password",pass)
        location.href="./login.html"
    }
    else{
        alert("Please Fill this Form")
    }
}
